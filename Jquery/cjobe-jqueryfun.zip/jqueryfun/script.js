$('.addClass').click(function(){
  //$('p').addClass('red');
  $(this).siblings('p').addClass('blue');
});

var beenClicked = false;
$('.show').hide();
$('.hideShow').click(function(){
  if (beenClicked == false) {
    $('.hide').hide();
    $('.show').show();
  }
  else {
    $('.hide').show();
    $('.show').hide();
  }
  beenClicked = !beenClicked;
});

$('.toggle').click(function(){
  $(this).siblings('p').toggle();
});

var beenSlid = false;
$('.window').click(function(){
  if (beenSlid == false) {
      $('.blade').slideUp();
  }
  else {
    $('.blade').slideDown();
    $('.fade').fadeIn();
  }
  beenSlid = !beenSlid;

});

$('.fade').click(function(){
  $(this).fadeOut("slow");
})

var numClick = 0;
$('.befAftApp').click(function(){
    if (numClick == 0) {
      $(this).siblings('p').before("before ");
      numClick++;
    }
    else if (numClick == 1) {
      $(this).siblings('p').append(" append ");
      numClick++;
    }
    else if (numClick == 2) {
      $(this).siblings('p').after("after ");
      numClick++;
    }
    else if (numClick == 3) {
      $(this).siblings('p').append("#Another append#");
      numClick = 0;
    }
})

$('.fakeAttr').click(function(){
  var fakeAttrStr = $(this).html();
  $(this).text(fakeAttrStr);
  console.log(fakeAttrStr);
});

$('.attrButton').click(function() {
  var attr = $('.fakeAttr').attr("class");
  $('.attrButton').text("class of above <p> is " + attr);
  console.log(attr);
})

$('.valForm').keyup(function() {
    var valFormTxt = $('.valForm').val();
    console.log(valFormTxt);
    $(this).siblings('p').text(valFormTxt);
});
