from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = 'it\'s a secret' 


@app.route('/')
def index_count():
    print(session)
    if 'times_visited' in session:
        session['times_visited'] = session.get('times_visited') + 1
        session['fake_count'] = session['times_visited'] + session['fake_count']
    else:
        session['times_visited'] = 1
        session['fake_count'] = session['times_visited']
    return render_template("index.html",  count = session['times_visited'], fake_count = session['fake_count'])

@app.route('/2')
def add_two():

    session['fake_count'] = session['fake_count'] +1
    return redirect('/')

@app.route('/add', methods=['POST'])
def add_number():
    print("hello")
    add_num = int(request.form['number'])
    # session['times_visited'] = session['times_visited'] + add_num
    session['fake_count'] = session['fake_count'] + add_num
    return redirect('/')

@app.route('/destroy_session')
def destroy_session():
    session.clear()
    return redirect("/")


if __name__=="__main__":
    app.run(debug=True)
